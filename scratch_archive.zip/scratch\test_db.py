import os
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

url = os.getenv("PROJECT_URL")
key = os.getenv("SERVICE_ROLE")

client = create_client(url, key)

res = client.table("admins").select("*").eq("user_id", 1161063594).execute()
print("ADMIN RECORD:", res.data)
