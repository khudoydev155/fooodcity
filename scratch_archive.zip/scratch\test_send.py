import httpx
import os
from dotenv import load_dotenv

load_dotenv()

token = os.getenv("BOT_TOKEN")
user_id = 1161063594

url = f"https://api.telegram.org/bot{token}/sendMessage"
data = {
    "chat_id": user_id,
    "text": "Hello from diagnostic script!"
}
res = httpx.post(url, json=data)
print("Send Message Status:", res.status_code)
print("Send Message Response JSON (unicode escape):", res.text.encode("unicode_escape").decode("ascii"))
