import os
import sys
from dotenv import load_dotenv
from supabase import create_client

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
load_dotenv()

url = os.getenv("PROJECT_URL")
key = os.getenv("SERVICE_ROLE")
client = create_client(url, key)

print("--- Testing immutability of category_code ---")
try:
    # Get a category
    cats = client.table("categories").select("*").limit(1).execute()
    if cats.data:
        cat = cats.data[0]
        cat_id = cat["id"]
        old_code = cat["category_code"]
        new_code = old_code + "_MOD"
        print(f"Attempting to update category {cat_id} code from {old_code} to {new_code}...")
        client.table("categories").update({"category_code": new_code}).eq("id", cat_id).execute()
        print("[FAIL] Updated category_code! Trigger failed to block update.")
    else:
        print("No categories found to test.")
except Exception as e:
    print("[SUCCESS] Successfully blocked category_code update! Error:", e)

print("--- Testing immutability of product_code ---")
try:
    # Get a menu item
    items = client.table("menu_items").select("*").limit(1).execute()
    if items.data:
        item = items.data[0]
        item_id = item["id"]
        old_code = item["product_code"]
        new_code = old_code + "-MOD"
        print(f"Attempting to update menu item {item_id} code from {old_code} to {new_code}...")
        client.table("menu_items").update({"product_code": new_code}).eq("id", item_id).execute()
        print("[FAIL] Updated product_code! Trigger failed to block update.")
    else:
        print("No menu items found to test.")
except Exception as e:
    print("[SUCCESS] Successfully blocked product_code update! Error:", e)
