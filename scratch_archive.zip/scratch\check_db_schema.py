import os
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

url = os.getenv("PROJECT_URL")
key = os.getenv("SERVICE_ROLE")

client = create_client(url, key)

try:
    res = client.table("categories").select("*").limit(1).execute()
    if res.data:
        print("CATEGORIES COLUMNS:", list(res.data[0].keys()))
    else:
        print("CATEGORIES empty")
except Exception as e:
    print("CATEGORIES ERROR:", e)

try:
    res = client.table("menu_items").select("*").limit(1).execute()
    if res.data:
        print("MENU ITEMS COLUMNS:", list(res.data[0].keys()))
    else:
        print("MENU ITEMS empty")
except Exception as e:
    print("MENU ITEMS ERROR:", e)
