import httpx

url = "https://worker-production-7c481.up.railway.app/health"
try:
    res = httpx.get(url, timeout=10)
    print("Health check response status:", res.status_code)
    print("Response text:", res.text)
except Exception as e:
    print("Failed to reach health endpoint:", e)
