import asyncio
import os
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

supabase_url = os.getenv("PROJECT_URL")
supabase_key = os.getenv("SERVICE_ROLE")

if not supabase_url or not supabase_key:
    print("Missing Supabase URL or SERVICE_ROLE")
    exit(1)

client = create_client(supabase_url, supabase_key)

try:
    buckets = client.storage.list_buckets()
    print("Buckets found:")
    for b in buckets:
        print(f"- {b.name} (public: {b.public})")
except Exception as e:
    print(f"Error listing buckets: {e}")
