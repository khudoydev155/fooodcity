
$SUPABASE_URL = "https://jciuzrttciqmmnweglpd.supabase.co"
$SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjaXV6cnR0Y2lxbW1ud2VnbHBkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgzMzUyMjgsImV4cCI6MjA5MzkxMTIyOH0.sBu-06SdGf28Py9FdJaRw1xd2OjaRrk7NGcFPe2gwGU"

$headers = @{
    "apikey" = $SUPABASE_KEY
    "Authorization" = "Bearer $SUPABASE_KEY"
    "Content-Type" = "application/json"
}

$updates = @{
    "2a0f3ba2-6bec-45b4-be36-54f19af56cde" = "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=800&q=80" # Iskandar Kabob
    "d5b72923-9c48-408e-bafb-debcbb77a5b7" = "https://images.unsplash.com/photo-1529042410759-befb1204b468?auto=format&fit=crop&w=800&q=80" # Tombik Doner
    "1204663f-2e47-4524-b04a-0359e24800fb" = "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=800&q=80" # Go'shtli Kushbashi
    "5153e5b5-fcd4-4995-92aa-47fb5d5668a7" = "https://images.unsplash.com/photo-1574085733277-851d9d856a3a?auto=format&fit=crop&w=800&q=80" # Karadenis Pide
    "83578477-d9b9-4dbf-af05-3325e85d15b5" = "https://images.unsplash.com/photo-1610192244261-3f33de3f55e4?auto=format&fit=crop&w=800&q=80" # Lavash
    "75729dfa-eaf6-447c-b808-370837b448bd" = "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=800&q=80" # Pishloqli Lavash
    "109cc855-911b-48b8-9447-ffc3a486cf94" = "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=800&q=80" # Pishloqli Mini Lavash (Using same cheese wrap photo)
    "30073282-4e99-4628-b7bd-006064a20611" = "https://images.unsplash.com/photo-1610192244261-3f33de3f55e4?auto=format&fit=crop&w=800&q=80" # Food City Lavash
    "04add6cd-aca8-4f79-af4b-b65dc991528d" = "https://images.unsplash.com/photo-1619740455993-9e612b1af08a?auto=format&fit=crop&w=800&q=80"  # Royal Double Hot-dog
}

foreach ($id in $updates.Keys) {
    $url = "$SUPABASE_URL/rest/v1/menu_items?id=eq.$id"
    $body = @{ image_url = $updates[$id] } | ConvertTo-Json
    Invoke-RestMethod -Uri $url -Method Patch -Headers $headers -Body $body
    Write-Host "Updated $id with $($updates[$id])"
}
