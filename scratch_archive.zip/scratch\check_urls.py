
import requests

urls = [
    "https://images.unsplash.com/photo-1662116765994-1e03f8481498?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1561651823-34fed022540e?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1574085733277-851d9d856a3a?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1610192244261-3f33de3f55e4?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1613514785940-daed07799d85?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1626700051175-6518c4793f1d?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1585032226651-759b368d724a?auto=format&fit=crop&w=800&q=80"
]

for url in urls:
    try:
        res = requests.head(url, allow_redirects=True)
        print(f"{url}: {res.status_code}")
    except Exception as e:
        print(f"{url}: ERROR {e}")
