import httpx
import os
from dotenv import load_dotenv

load_dotenv()

token = os.getenv("BOT_TOKEN")
webhook_url = "https://worker-production-7c481.up.railway.app/webhook/muhammad5818xudoyberganov"

url = f"https://api.telegram.org/bot{token}/setWebhook"
data = {
    "url": webhook_url,
    "allowed_updates": ["message", "callback_query", "web_app_data"],
    "secret_token": "muhammad5818xudoyberganov"
}

res = httpx.post(url, json=data)
print("Set Webhook Status:", res.status_code)
print("Set Webhook Response:", res.json())
