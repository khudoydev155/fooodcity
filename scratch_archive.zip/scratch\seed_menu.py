import os
from dotenv import load_dotenv
from supabase import create_client, Client

load_dotenv()

url = os.environ.get("PROJECT_URL")
key = os.environ.get("SERVICE_ROLE")

if not url or not key:
    print("Supabase credentials not found in .env")
    exit(1)

supabase: Client = create_client(url, key)

def run_seed():
    print("Step 1: Cleaning old seed data...")
    # DELETE FROM menu_items WHERE total_ordered = 0 AND created_by IS NULL
    res = supabase.table('menu_items').delete().eq('total_ordered', 0).is_('created_by', 'null').execute()
    print(f"Deleted {len(res.data) if res.data else 0} items.")

    print("Updating categories...")
    # Update categories to match Foood City menu
    supabase.table('categories').update({
        'name_uz': 'Pizzalar', 'name_ru': 'Пиццы', 'name_en': 'Pizzas', 'emoji': '🍕'
    }).eq('sort_order', 2).execute()

    print("Upserting new categories...")
    categories = [
        {'id': 'aaaaaaaa-0001-0001-0001-000000000001', 'name_uz': 'Kabob va Donerlar', 'name_ru': 'Кабобы и Донеры', 'name_en': 'Kebabs & Doners', 'emoji': '🥙', 'sort_order': 2, 'is_active': True},
        {'id': 'aaaaaaaa-0002-0002-0002-000000000002', 'name_uz': 'Pide va Maxsus', 'name_ru': 'Пиде и Спешл', 'name_en': 'Pide & Special', 'emoji': '🫓', 'sort_order': 3, 'is_active': True},
        {'id': 'aaaaaaaa-0003-0003-0003-000000000003', 'name_uz': 'Lavashlar', 'name_ru': 'Лаваши', 'name_en': 'Lavash', 'emoji': '🌯', 'sort_order': 4, 'is_active': True},
        {'id': 'aaaaaaaa-0004-0004-0004-000000000004', 'name_uz': 'Hot-dog va Burgerlar', 'name_ru': 'Хот-доги и Бургеры', 'name_en': 'Hot-dogs & Burgers', 'emoji': '🍔', 'sort_order': 5, 'is_active': True}
    ]
    for cat in categories:
        supabase.table('categories').upsert(cat).execute()

    print("Step 2: Adding all Foood City menu items...")
    menu_items = [
        # PIZZALAR
        {
            'category_id': '22222222-2222-2222-2222-222222222222',
            'name_uz': 'Pepperoni Pizza', 'name_ru': 'Пицца Пепперони', 'name_en': 'Pepperoni Pizza',
            'description_uz': "Mazali pepperoni va mozzarella pishlog'i bilan", 
            'description_ru': 'С пепперони и сыром моцарелла',
            'description_en': 'With pepperoni and mozzarella cheese',
            'price': 65000, 'image_url': 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍕', 'badge': '🔥 Hit', 'is_available': True, 'sort_order': 1, 'total_ordered': 0
        },
        {
            'category_id': '22222222-2222-2222-2222-222222222222',
            'name_uz': "Go'sht Pizza", 'name_ru': 'Пицца Мясной', 'name_en': 'Meat Pizza',
            'description_uz': "To'lib-toshib turgan go'shtli pizza", 
            'description_ru': 'Сытная пицца с мясной начинкой',
            'description_en': 'Hearty pizza with meat filling',
            'price': 75000, 'image_url': 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍕', 'badge': None, 'is_available': True, 'sort_order': 2, 'total_ordered': 0
        },
        {
            'category_id': '22222222-2222-2222-2222-222222222222',
            'name_uz': 'Food City Miks Pizza', 'name_ru': 'Пицца Микс Food City', 'name_en': 'Food City Mix Pizza',
            'description_uz': "Food City'ning maxsus miks pizzasi",
            'description_ru': 'Фирменная микс пицца Food City',
            'description_en': 'Food City special mix pizza',
            'price': 70000, 'image_url': 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍕', 'badge': '⭐ Maxsus', 'is_available': True, 'sort_order': 3, 'total_ordered': 0
        },
        {
            'category_id': '22222222-2222-2222-2222-222222222222',
            'name_uz': 'Margarita Pizza', 'name_ru': 'Пицца Маргарита', 'name_en': 'Margherita Pizza',
            'description_uz': 'Klassik margarita - tomat sousi va mozzarella',
            'description_ru': 'Классическая маргарита с томатным соусом и моцареллой',
            'description_en': 'Classic margherita with tomato sauce and mozzarella',
            'price': 55000, 'image_url': 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍕', 'badge': None, 'is_available': True, 'sort_order': 4, 'total_ordered': 0
        },
        # KABOB VA DONERLAR
        {
            'category_id': 'aaaaaaaa-0001-0001-0001-000000000001',
            'name_uz': 'Iskandar Kabob', 'name_ru': 'Искандар Кабоб', 'name_en': 'Iskander Kebab',
            'description_uz': 'Mazali iskandar kabob, tavsiya etamiz!',
            'description_ru': 'Вкусный кебаб Искандар, рекомендуем!',
            'description_en': 'Delicious Iskander kebab, highly recommended!',
            'price': 52000, 'image_url': 'https://avatars.mds.yandex.net/get-eda/3709189/8ab11c5225ab3d174f55ca3aff94c318/orig',
            'emoji': '🥙', 'badge': '🔥 Hit', 'is_available': True, 'sort_order': 1, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0001-0001-0001-000000000001',
            'name_uz': 'Tombik Doner', 'name_ru': 'Томбик Донер', 'name_en': 'Tombik Doner',
            'description_uz': 'Yangi sabzavotlar va maxsus sous bilan doner',
            'description_ru': 'Донер со свежими овощами и фирменным соусом',
            'description_en': 'Doner with fresh vegetables and special sauce',
            'price': 35000, 'image_url': 'https://images.unsplash.com/photo-1642645229107-160eb820c7cc?w=500&auto=format&fit=crop&q=80',
            'emoji': '🥙', 'badge': None, 'is_available': True, 'sort_order': 2, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0001-0001-0001-000000000001',
            'name_uz': 'Beyti Kabob', 'name_ru': 'Бейти Кабоб', 'name_en': 'Beyti Kebab',
            'description_uz': "Nozik go'sht va baharom ziravorlar bilan kabob",
            'description_ru': 'Кебаб из нежного мяса с ароматными специями',
            'description_en': 'Kebab with tender meat and aromatic spices',
            'price': 48000, 'image_url': 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=500&auto=format&fit=crop&q=80',
            'emoji': '🥙', 'badge': None, 'is_available': True, 'sort_order': 3, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0001-0001-0001-000000000001',
            'name_uz': 'Xaggi', 'name_ru': 'Хагги', 'name_en': 'Haggi',
            'description_uz': "Maxsus tayyorlangan go'shtli xaggi",
            'description_ru': 'Специально приготовленный мясной хагги',
            'description_en': 'Specially prepared meat haggi',
            'price': 35000, 'image_url': 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?w=500&auto=format&fit=crop&q=80',
            'emoji': '🥙', 'badge': None, 'is_available': True, 'sort_order': 4, 'total_ordered': 0
        },
        # PIDE VA MAXSUS
        {
            'category_id': 'aaaaaaaa-0002-0002-0002-000000000002',
            'name_uz': 'Pishloqli Pide', 'name_ru': 'Пиде с сыром', 'name_en': 'Cheese Pide',
            'description_uz': "Yangi pishloq bilan to'ldirilgan pide",
            'description_ru': 'Пиде с нежным свежим сыром',
            'description_en': 'Pide filled with fresh cheese',
            'price': 37000, 'image_url': 'https://imageproxy.wolt.com/assets/687f14c902a50c046d193233',
            'emoji': '🫓', 'badge': None, 'is_available': True, 'sort_order': 1, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0002-0002-0002-000000000002',
            'name_uz': "Go'shtli Kushbashi Pide", 'name_ru': 'Пиде с мясной кушбаши', 'name_en': 'Meat Kushbashi Pide',
            'description_uz': "Kushbashi go'shti bilan to'ldirilgan pide",
            'description_ru': 'Пиде с сочной мясной кушбаши',
            'description_en': 'Pide filled with juicy meat kushbashi',
            'price': 50000, 'image_url': 'https://avatars.mds.yandex.net/i?id=6c2c70b46c4dd0cb50387e0b240ef2155745a042-7998976-images-thumbs&n=13',
            'emoji': '🫓', 'badge': '🔥 Hit', 'is_available': True, 'sort_order': 2, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0002-0002-0002-000000000002',
            'name_uz': 'Karadenis Pide', 'name_ru': 'Пиде Карадениз', 'name_en': 'Karadeniz Pide',
            'description_uz': 'Qora dengiz uslubida tayyorlangan pide',
            'description_ru': 'Пиде в стиле Черного моря',
            'description_en': 'Black Sea style pide',
            'price': 52000, 'image_url': 'https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=500&auto=format&fit=crop&q=80',
            'emoji': '🫓', 'badge': None, 'is_available': True, 'sort_order': 3, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0002-0002-0002-000000000002',
            'name_uz': 'Speshal Doner', 'name_ru': 'Спешл Донер', 'name_en': 'Special Doner',
            'description_uz': 'Maxsus tayyorlangan speshal doner',
            'description_ru': 'Специально приготовленный спешл донер',
            'description_en': 'Specially prepared special doner',
            'price': 53000, 'image_url': 'https://images.unsplash.com/photo-1529042410759-befb1204b468?w=500&auto=format&fit=crop&q=80',
            'emoji': '🥙', 'badge': '⭐ Maxsus', 'is_available': True, 'sort_order': 4, 'total_ordered': 0
        },
        # LAVASHLAR
        {
            'category_id': 'aaaaaaaa-0003-0003-0003-000000000003',
            'name_uz': 'Lavash', 'name_ru': 'Лаваш', 'name_en': 'Lavash',
            'description_uz': "Go'sht, yangi sabzavotlar, ziravorlar va sous bilan lavash",
            'description_ru': 'Нежная начинка из мяса, свежих овощей, ароматных специй и соуса, обёрнутая в лаваш',
            'description_en': 'Tender meat, fresh vegetables, aromatic spices and sauce wrapped in lavash',
            'price': 30000, 'image_url': 'https://imageproxy.wolt.com/menu/menu-images/shared/e3a2ec5a-794b-11ee-93a3-fe6ab45d5259_et_lavash.jpg',
            'emoji': '🌯', 'badge': None, 'is_available': True, 'sort_order': 1, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0003-0003-0003-000000000003',
            'name_uz': 'Pishloqli Lavash', 'name_ru': 'Лаваш с сыром', 'name_en': 'Cheese Lavash',
            'description_uz': 'Nozik pishloq bilan sharbatli lavash',
            'description_ru': 'Такой же сочный лаваш, но только уже с нежным и тающим сыром',
            'description_en': 'The same juicy lavash but with tender melting cheese',
            'price': 37000, 'image_url': 'https://imageproxy.wolt.com/assets/687f14c902a50c046d193233',
            'emoji': '🌯', 'badge': None, 'is_available': True, 'sort_order': 2, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0003-0003-0003-000000000003',
            'name_uz': 'Mini Lavash', 'name_ru': 'Мини Лаваш', 'name_en': 'Mini Lavash',
            'description_uz': "Nozik go'sht, yangi sabzavotlar va sous bilan kichik lavash",
            'description_ru': 'Богатая начинка из нежного мяса, свежих овощей и соуса, но только в уменьшенной форме',
            'description_en': 'Rich filling of tender meat, fresh vegetables and sauce in a smaller form',
            'price': 27000, 'image_url': 'https://images.unsplash.com/photo-1509722747041-616f39b57569?w=500&auto=format&fit=crop&q=80',
            'emoji': '🌯', 'badge': None, 'is_available': True, 'sort_order': 3, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0003-0003-0003-000000000003',
            'name_uz': 'Pishloqli Mini Lavash', 'name_ru': 'Мини Лаваш с сыром', 'name_en': 'Mini Cheese Lavash',
            'description_uz': "Pishloqli kichik lavash - har bir luqmada boy ta''m",
            'description_ru': 'Уменьшенная форма нашего лаваша с сыром. Богатство в каждом вкусе!',
            'description_en': 'Smaller form of our cheese lavash. Richness in every bite!',
            'price': 30000, 'image_url': 'https://images.unsplash.com/photo-1613514785940-daed07799d85?w=500&auto=format&fit=crop&q=80',
            'emoji': '🌯', 'badge': None, 'is_available': True, 'sort_order': 4, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0003-0003-0003-000000000003',
            'name_uz': 'Food City Lavash', 'name_ru': 'Лаваш Food City', 'name_en': 'Food City Lavash',
            'description_uz': "Food City'ning maxsus lavashi - klassik taomning o''zimizning versiyasi!",
            'description_ru': 'Лаваш Food City - наша авторская версия классического блюда!',
            'description_en': 'Food City Lavash - our own version of the classic dish!',
            'price': 42000, 'image_url': 'https://images.unsplash.com/photo-1562059390-a761a0847685?w=500&auto=format&fit=crop&q=80',
            'emoji': '🌯', 'badge': '⭐ Maxsus', 'is_available': True, 'sort_order': 5, 'total_ordered': 0
        },
        # HOT-DOG VA BURGERLAR
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': 'Hot-dog', 'name_ru': 'Хот-дог', 'name_en': 'Hot-dog',
            'description_uz': "Amerika uslubidagi boy ta''m: sharbatli kolbasa, yumshoq non, maxsus sous",
            'description_ru': 'Насыщенный вкус американского стиля: сочная сосиска, пышная булочка, фирменный соус',
            'description_en': 'Rich American style taste: juicy sausage, fluffy bun, signature sauce',
            'price': 15000, 'image_url': 'https://images.unsplash.com/photo-1619740455993-9e612b1af08a?w=500&auto=format&fit=crop&q=80',
            'emoji': '🌭', 'badge': None, 'is_available': True, 'sort_order': 1, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': "Qirollik Qo'shaloq Hot-dog", 'name_ru': 'Двойной Королевский Хот-дог', 'name_en': 'Double Royal Hot-dog',
            'description_uz': "Xuddi shunday hot-dog - faqat qirollarcha, ikki baravar ta''m va rohat",
            'description_ru': 'Тот же наш хот-дог - только по-королевски, с двойным вкусом, двойным удовольствием',
            'description_en': 'The same hot-dog - but royally, with double taste and double pleasure',
            'price': 20000, 'image_url': 'https://алитет-саратов.рф/img/24.12.2025/2512256.png',
            'emoji': '🌭', 'badge': None, 'is_available': True, 'sort_order': 2, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': 'Gamburger', 'name_ru': 'Гамбургер', 'name_en': 'Hamburger',
            'description_uz': "Bizning klassikamiz: sharbatli kotlet, yangi sabzavotlar, har bir luqmada mukammal uyg''unlik",
            'description_ru': 'Наша классика: сочная котлета, свежие овощи, идеально сочетающиеся в каждом куске',
            'description_en': 'Our classic: juicy patty, fresh vegetables, perfectly combined in every bite',
            'price': 30000, 'image_url': 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍔', 'badge': None, 'is_available': True, 'sort_order': 3, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': 'Chizburger', 'name_ru': 'Чизбургер', 'name_en': 'Cheeseburger',
            'description_uz': "Sharbatli kotlet, nozik pishloq va sabzavotlarning tengsiz kombinatsiyasi",
            'description_ru': 'Непревзойденное сочетание сочной котлеты, нежного сыра и овощей. Вкус, который всегда в моде!',
            'description_en': 'Unrivaled combination of juicy patty, tender cheese and vegetables. Always in style!',
            'price': 35000, 'image_url': 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍔', 'badge': '🔥 Hit', 'is_available': True, 'sort_order': 4, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': "Qo'shaloq Gamburger", 'name_ru': 'Двойной Гамбургер', 'name_en': 'Double Hamburger',
            'description_uz': "Ikki sharbatli kotlet, ikki porsiya yangi sabzavotlar, barchasi yumshoq nonda",
            'description_ru': 'Две сочные котлеты, двойная порция свежих овощей, все в одной пышной булочке!',
            'description_en': 'Two juicy patties, double portion of fresh vegetables, all in one fluffy bun!',
            'price': 43000, 'image_url': 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍔', 'badge': None, 'is_available': True, 'sort_order': 5, 'total_ordered': 0
        },
        {
            'category_id': 'aaaaaaaa-0004-0004-0004-000000000004',
            'name_uz': "Qo'shaloq Chizburger", 'name_ru': 'Двойной Чизбургер', 'name_en': 'Double Cheeseburger',
            'description_uz': "Xuddi shunday chizburger, faqat ikki baravar ko''p - sharbatli kotlet, nozik pishloq va yangi sabzavotlar",
            'description_ru': 'Такой же, как и наш чизбургер, только в два раза больше - сочной котлеты, нежного сыра и свежих овощей',
            'description_en': 'Same as our cheeseburger but twice as much - juicy patty, tender cheese and fresh vegetables',
            'price': 48000, 'image_url': 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80',
            'emoji': '🍔', 'badge': None, 'is_available': True, 'sort_order': 6, 'total_ordered': 0
        }
    ]
    
    for item in menu_items:
        supabase.table('menu_items').insert(item).execute()
    
    print("Seeding complete!")

if __name__ == "__main__":
    run_seed()
