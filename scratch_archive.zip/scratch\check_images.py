import httpx
import json

SUPABASE_URL = "https://jciuzrttciqmmnweglpd.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjaXV6cnR0Y2lxbW1ud2VnbHBkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgzMzUyMjgsImV4cCI6MjA5MzkxMTIyOH0.sBu-06SdGf28Py9FdJaRw1xd2OjaRrk7NGcFPe2gwGU"

headers = {
    "apikey": SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}"
}

def get_menu():
    url = f"{SUPABASE_URL}/rest/v1/menu_items?select=id,name_uz,image_url"
    response = httpx.get(url, headers=headers)
    return response.json()

if __name__ == "__main__":
    menu = get_menu()
    items_to_check = [
        "Iskandar Kabob", "Lavash", "Go'shtli Kushbashi", "Tombik Doner", 
        "Qirollik Qo'shaloq Hot-dog", "Pishloqli Mini lavash", 
        "Foood City lavash", "Karadenis Pide", "Pishloqli Lavash"
    ]
    
    results = []
    for item in menu:
        if any(name.lower() in item['name_uz'].lower() for name in items_to_check):
            results.append(item)
    
    print(json.dumps(results, indent=2))
