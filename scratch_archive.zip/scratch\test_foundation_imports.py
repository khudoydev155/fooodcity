import os
import sys
from dotenv import load_dotenv

# Add workspace path to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

load_dotenv()

print("Verifying imports...")

try:
    from bot.config import config
    print("[OK] Config imported successfully")
except Exception as e:
    print("[ERROR] Config import failed:", str(e))
    sys.exit(1)

try:
    from bot.database import db
    print("[OK] DatabaseManager imported successfully")
except Exception as e:
    print("[ERROR] DatabaseManager import failed:", str(e))
    sys.exit(1)

try:
    from bot.handlers.admin import router as admin_router
    from bot.handlers.menu_wizard import router as wizard_router
    print("[OK] Handlers imported successfully")
except Exception as e:
    print("[ERROR] Handlers import failed:", str(e))
    sys.exit(1)

print("[SUCCESS] All imports are successful and correct!")
