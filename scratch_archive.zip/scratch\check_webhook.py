import httpx
import os
from dotenv import load_dotenv

load_dotenv()

token = os.getenv("BOT_TOKEN")
print("Bot Token starts with:", token[:10] if token else "None")

url = f"https://api.telegram.org/bot{token}/getWebhookInfo"
res = httpx.get(url)
print("Webhook Info:", res.json())
