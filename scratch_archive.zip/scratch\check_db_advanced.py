import os
import sys
from dotenv import load_dotenv
from supabase import create_client

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
load_dotenv()

url = os.getenv("PROJECT_URL")
key = os.getenv("SERVICE_ROLE")
client = create_client(url, key)

print("--- Checking menu_item_images ---")
try:
    res = client.table("menu_item_images").select("*").limit(1).execute()
    print("[OK] menu_item_images exists. Data:", res.data)
except Exception as e:
    print("[ERROR] menu_item_images:", e)

print("--- Checking product_code_sequences ---")
try:
    res = client.table("product_code_sequences").select("*").limit(1).execute()
    print("[OK] product_code_sequences exists. Data:", res.data)
except Exception as e:
    print("[ERROR] product_code_sequences:", e)

print("--- Testing generate_product_code RPC ---")
try:
    res = client.rpc("generate_product_code", {"p_category_code": "PZZ"}).execute()
    print("[OK] generate_product_code RPC succeeded. Generated code:", res.data)
except Exception as e:
    print("[ERROR] generate_product_code RPC:", e)
