import os
import sys
import asyncio
from dotenv import load_dotenv

# Add workspace path to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Load dot env before importing any app files
load_dotenv()

async def test():
    print("Testing DB queries and connection...")
    
    # Import config and print credentials
    from bot.config import config
    print("BOT_TOKEN length:", len(config.BOT_TOKEN))
    print("SUPABASE_URL:", config.SUPABASE_URL)
    
    # Import db
    from bot.database import db
    if not db.client:
        print("[ERROR] Database client is None")
        return
        
    try:
        # Test categories fetch
        print("Fetching categories...")
        cats = await db.get_categories(active_only=False)
        print(f"[OK] Fetched {len(cats)} categories")
        if cats:
            print("First category details (keys):", list(cats[0].keys()))
            
        # Test menu items fetch
        print("Fetching menu items...")
        menu = await db.get_menu_items(available_only=False)
        print(f"[OK] Fetched {len(menu)} menu items")
        if menu:
            print("First menu item details (keys):", list(menu[0].keys()))
            
    except Exception as e:
        print("[ERROR] Query execution failed:", str(e))

if __name__ == "__main__":
    asyncio.run(test())
